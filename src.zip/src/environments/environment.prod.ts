export const environment = {
  production: true
};

export const api_base_url = 'http://localhost:3000/';
