import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'top-products',
  templateUrl: './top-products.component.html',
  styleUrls: ['./top-products.component.css']
})
export class TopProductsComponent{


}
