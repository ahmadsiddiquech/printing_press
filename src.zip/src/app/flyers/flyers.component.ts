import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'flyers',
  templateUrl: './flyers.component.html',
  styleUrls: ['./flyers.component.css']
})
export class FlyersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
