import { Component, OnInit } from '@angular/core';
import { ProductsService } from '../common/services/products.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  cart: any;
  result: any;
  cart_products: any = [];
  constructor(private productService: ProductsService) {
    this.cart = localStorage.getItem('cart');
    if (this.cart) {
      this.cart = JSON.parse(this.cart);
      for (let i = 0; i < this.cart.length; i++) {
        this.productService.getProductByProductID(this.cart[i].product_id, this.cart[i].product_turnaround)
          .subscribe(
            response => {
              this.result = response;
              if (this.result.success) {
                this.result.data[0].product_turnaround = this.cart[i].product_turnaround;
                this.result.data[0].total_price = Number(this.cart[i].price) + (Number(this.cart[i].price) * (Number(this.cart[i].vat) / 100));
                this.cart_products.push(this.result.data[0]);
              } else {
                this.cart_products = [{ id: 0, name: 'No Record Found' }];
              }
            }
          )
      }
    }

  }

  delete_product(id: any, product_turnaround: any) {
    this.cart = localStorage.getItem('cart');
    this.cart = JSON.parse(this.cart);

    for (let i = 0; i < this.cart.length; i++) {
      if (this.cart[i].product_id == id && this.cart[i].product_turnaround == product_turnaround) {
        this.cart.splice(i, 1);
      }
    }
    localStorage.removeItem('cart');
    localStorage.setItem("cart", JSON.stringify(this.cart));
    window.location.reload();
  }
}